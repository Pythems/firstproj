"""
Package for creating and drawing trees.
"""
__version__ = "v0.2.4"
__author__ = "Pixelwar"
